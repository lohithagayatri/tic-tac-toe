from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_login import LoginManager, UserMixin
from pymongo import MongoClient

app = Flask(__name__)
app.config['SECRET_KEY'] = 'Tarun@123'

username = "dtarunsai08"
password = "Tarun%40123"  # Escape "@" symbol

client = MongoClient(f"mongodb+srv://{username}:{password}@cluster0.q8xqtl8.mongodb.net/")
db = client["Agriculture"]  

USER_ROLES = {'farmer': 'farmer', 'customer': 'customer'}

# User model (both for farmer and customer)
class User(UserMixin):
  def __init__(self, name, email, phone, location, password, role):
    self.name = name
    self.email = email
    self.phone = phone
    self.location = location
    self.password = password
    self.role = role
    if self.role == 'customer':
        self.cart = []

  @classmethod
  def find_by_username(cls, role, email):
    user_data = db[USER_ROLES[role]].find_one({"email": email}, projection={'_id': False}) # Assuming a single "Users" collection
    return cls(**user_data) if user_data else None

  def verify_password(self, password):
    return self.password == password

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # Redirect to login route if not authenticated

# User loader function (retrieves user by username from MongoDB)
@login_manager.user_loader
def load_user(username):
    return User.find_by_username(username)

# Check if user is logged in
def is_logged_in():
    return 'user' in session

# Signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        location = request.form['location']
        password = request.form['password']
        role = request.form['role']

        if db[USER_ROLES[role]].find_one({"email": email}):
            error = {}
            error['email'] = 'User already exists, please login'
            return render_template('login.html', errors=error)
        else:
            new_user = User(name, email, phone, location, password, role)  
            db[USER_ROLES[role]].insert_one(new_user.__dict__) 
            return redirect(url_for('login'))
    return render_template('signup.html', roles=USER_ROLES)

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        user = User.find_by_username(role,email)
        if user and user.verify_password(password): 
            session['user'] = user.__dict__
            return redirect(url_for('index'))
        else:
            error = {}
            if not user:
                error['email'] = "User Doesn't exist"
                return render_template('signup.html', errors=error)
            else:
                error['password'] = 'Invalid Password'
            return render_template('login.html', errors=error)
    return render_template('login.html')

# Logout route
@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

class Product:
  def __init__(self, farmer_email, name, description=None, price=0.0, image_url=None, stock=0):
    self.farmer_email = farmer_email 
    self.name = name
    self.description = description
    self.price = price
    self.image_url = image_url
    self.stock = stock

def farmer_dashboard():
  farmer = session['user']  
  products = db["products"].find({"farmer_email": farmer['email']})  

  if request.method == "POST":
    name = request.form["name"]
    description = request.form.get("description")
    price = float(request.form["price"])
    image_url = request.form.get("image_url")
    stock = int(request.form["stock"])

    existing_product = db["products"].find_one({"farmer_email": farmer['email'], "name": name})
    if existing_product:
      error_message = "Product with the same name already exists."
      print(error_message)
      return render_template("addProduct.html", error=error_message)

    new_product = Product(farmer['email'], name, description, price, image_url, stock)

    db["products"].insert_one(new_product.__dict__)
    return redirect(url_for("farmer_dashboard_route"))  
  else:
    return render_template("farmer.html", products=products)

@app.route("/addProduct",methods=["POST","GET"])
def addProduct():
    if request.method == "POST":
        farmer_dashboard()
    return render_template("addProduct.html")

@app.route("/farmer")  
def farmer_dashboard_route():
    return farmer_dashboard()

@app.route('/')
def index():
    if is_logged_in():
        user = session['user']
        if user['role'] == 'farmer':
            return redirect(url_for('farmer_dashboard_route'))
        else:
            return render_template('customer.html')
    else:
        return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)
