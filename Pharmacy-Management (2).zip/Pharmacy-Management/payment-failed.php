<?php 
if(isset($_GET)){
    
    echo "<pre>";
    print_r($_GET);
    echo "</p>";
}
?>